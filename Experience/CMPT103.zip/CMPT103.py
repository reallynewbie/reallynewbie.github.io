# Program: Project for CMPT 103, where we are doing a population/moving
# simulation.
# Bruce Leung
# Conditions in which this program stops executing the Run Command:
# 1.  If an invalid entry into similarity is entered during the run command.
# 2.  Every agent is content and there are no more agents to be moved.
# 3.  A step counter is present. Each "step" which is taken will increment this 
#     counter until it reaches 300, in which case, Run will stop running.
from graphics import *
import random

win = None

square_list = [[None for x in range(30)] for y in range(30)]
square_color = [[None for x in range(30)] for y in range(30)] # 0 = white, 1 = red, 2 = blue
button_text = ["Reset", "Step", "Run", "Exit"] 
button_list = []
empty_space = []
text_box = list()
similarity = 0
step_counter = 0

#---------------------------------------------------------------
# Drawing the UI and Randomizing the squares
#---------------------------------------------------------------
# Syntax: draw_square(index_x, index_y, x, y)
# Parameter: index_x - the x location in square_list
#            index_y - the y location in square_list
#            x - the x location to start drawing the square
#            y - the y location to start drawing the square.
# Return Value: None
# Description: Draws a square at X/Y location and updates the square list.
def draw_square(index_x, index_y, x, y):
    square = Rectangle(Point(x, y), Point(x+20, y+20))
    square.draw(win)
    square_list[index_x][index_y] = square

# Syntax: draw_squares()
# Parameter: None
# Return Value: None
# Description: Calls draw_square 30x30 times to create the picture.    
def draw_squares():
    for y in range(30):
        for x in range(30):
            draw_square(x, y, 5+x*20, 5+y*20)

# Syntax: randomizer()
# Parameter: None
# Return Value: None
# Description: Decides which squares are to be Blank, Red, or Blue.  And sets
#              the fill for each square.
def randomizer():
    global square_color
    global empty_square
    global step_counter
    
    step_counter = 0 #reset step counter upon randomizing.
    square_color = [[None for x in range(30)] for y in range(30)]
           
    emptyCounter = 0
    redCounter = 0
    blueCounter = 0
    randomX = 0
    randomY = 0
    
    while emptyCounter < 90:
        randomX = random.randint(0,29)
        randomY = random.randint(0,29)
        if square_color[randomX][randomY] != 0:
            square_color[randomX][randomY] = 0
            empty_space.append([randomX, randomY])
            square_list[randomX][randomY].setFill("White")
            emptyCounter += 1
    
    for x in range(30):
        for y in range(30):
            if square_color[x][y] == None:
                square_color[x][y] = random.choice([1, 2])
                if square_color[x][y] == 1:
                    if redCounter < 405:
                        square_list[x][y].setFill("Red")
                        redCounter += 1                        
                    else:
                        square_color[x][y] = 2
                        square_list[x][y].setFill("Blue")
                        blueCounter += 1                        
                else:
                    if blueCounter < 405:
                        square_list[x][y].setFill("Blue")
                        blueCounter += 1
                    else:
                        square_color[x][y] = 1
                        square_list[x][y].setFill("Red")
                        redCounter += 1                         
    return

# Syntax: drawButton(x, y, y_index)
# Parameter: x - the x location to draw the button
#            y - the y location to draw the button
#            y_index - where to look in button_text to find the text to place
#                      on the button.
# Return Value: None
# Description: Draws the button depending on what is given to the function.
def drawButton(x, y, y_index):
    button = Rectangle(Point(x, y+y_index*20), Point(x+250, y+100 + y_index*20))
    button.setFill("gray")
    button.draw(win)
    button_list.append(button)
    
    txt_button = Text(Point(x+125, y+50 + y_index*20), button_text[y_index])
    txt_button.setSize(20)
    txt_button.setStyle("bold")
    txt_button.draw(win)

# Syntax: drawTextBox(x, y)
# Parameter: x - the x location to draw the TextBox
#            y - the y location to draw the TextBox
# Return Value: None
# Description: Draws the TextBox for similarity depending on what is given to 
#              the function.  Also draws the Error Box for when the user inputs
#              an invalid similarity value.
def drawTextBox(x,y):
    text = Text(Point(x,y),"Similarity:  ")
    text.draw(win)
    
    textBox = Entry(Point(x+70,y),5)
    textBox.setText("0")
    textBox.draw(win)
    text_box.append(textBox)    
    
    errorText = Text(Point(x+50,y+30),"")
    errorText.setStyle("bold")
    errorText.draw(win)
    text_box.append(errorText)
    
    percent = Text(Point(x+110,y),"%")
    percent.draw(win)    

# Syntax: drawSteps(x, y, steps)
# Parameter: x - the x location to draw the Step Counter
#            y - the y location to draw the Step Counter
#            steps - The number of steps that have been taken
# Return Value: None
# Description: Draws the Step Counter box.
def drawSteps(x,y,steps):
    string = "Steps:  " + str(steps)
    steps = Text(Point(x,y),string)
    steps.draw(win)
    text_box.append(steps)
# Syntax: updateSteps(step
# Parameter: step - the number of steps that have been taken
# Return Value: None
# Description: updates the step counter.    
def updateSteps(step):
    string = "Steps:  " + str(step)
    text_box[2].setText(string)
#---------------------------------------------------------------
# Doing one step of the program
#---------------------------------------------------------------

# Syntax: oneStep()
# Parameter: None
# Return Value: None
# Description: Calls the functions necessary to run the simulation for one step.  
def oneStep():
    global empty_spaces
    global square_color
    global similarity
    global step_counter
        
    #updates similarity to be used for this step.    
    updateSimilarity()
    
    movementRequired = False
    squaresToBeMoved = []
    
    #kicks the program out if the similarity is not valid`
    if similarity == None or similarity == "rangeErr":
        return 1
    
    for x in range(30):
        for y in range(30):
            if square_color[x][y] in [1,2]:
                movementRequired = happyCheck(x,y,square_color[x][y])
                if movementRequired:
                    squaresToBeMoved.append([x,y])
    
    if len(squaresToBeMoved) == 0: #if you're out of squares, stop here.
        return True
    
    for squares in squaresToBeMoved:
        randomNum = random.randint(0,89)
        moveSquare(squares[0],squares[1],empty_space[randomNum][0], 
                   empty_space[randomNum][1])
        empty_space.pop(randomNum)
        empty_space.append(squares)
    
    step_counter += 1
    updateSteps(step_counter)
    if step_counter >=300:#if you've moved 300 steps, then stop.
        errorBox("300 Steps Exceeded")
        return True    
    
    return False

# Syntax: moveSquare(fromX, fromY, toX, toY)
# Parameter: fromX - the first square's X location
#            fromY - the first square's Y location
#            toX - the square you're moving to's X location.
#            toY - the square you're moving to's Y location.
# Return Value: None
# Description: Moves the square at [fromX][fromY] to [toX][toY] and vice versa..  
def moveSquare(fromX, fromY, toX, toY):
    global square_color
    global square_list
    
    from_Color = square_color[fromX][fromY]
    to_Color = square_color[toX][toY]
    square_color[fromX][fromY] = to_Color
    square_color[toX][toY] = from_Color
    square_list[fromX][fromY].setFill('White')
    if from_Color == 1:
        square_list[toX][toY].setFill('Red')
    if from_Color == 2:
        square_list[toX][toY].setFill('Blue')
    if from_Color == 0:
        print("Why is this White?")
                
#---------------------------------------------------------------
# Checking if the squares need to move
#---------------------------------------------------------------

# Syntax: colorCheck(color, colorDict)
# Parameter: color - the current color
#            colorDict - a dictionary keeping track of the count of all numbers.
# Return Value: colorDict - The updated dictionary.
# Description: Updates the dictionary with new numbers depending on the color.
def colorCheck(color, colorDict):
    if color == 1:
        colorDict['red'] += 1
        return colorDict
    if color == 2:
        colorDict['blue'] += 1
        return colorDict
    if color == 0:#for debugging, take out
        colorDict['blank'] += 1
        return colorDict

# Syntax: happyCheck(x_location,y_location,currentColor)
# Parameter: x_location - the square's x location
#            y_location - the square's y location
#            currentColor - the square's color
# Return Value: True - if the agent is content with it's location.
#               False - if the agent is not content.
# Description: Checks the square's surrounding spaces and returns True/False
#              depending if the square is happy where it is.
def happyCheck(x_location,y_location,currentColor):
    global square_color
    global similarity
    
    colorCount = {'red' : 0, 'blue' : 0, 'blank' : 0}
    
    x_search = [x_location-1, x_location, x_location+1]
    y_search = [y_location-1, y_location, y_location+1]
    
    #updates the range if the range surpasses the min/max range of the grid
    y_range = [0, 3]  
    if y_search[0] < 0:
        y_range[0] = 1
    if y_search[2] > 29:
        y_range[1] = 2
    
    #check row above
    if x_search[0] >= 0:
        for i in range(y_range[0], y_range[1]):
            colorCount = colorCheck(square_color[x_search[0]][y_search[i]],
                                     colorCount)
    #row below
    if x_search[2] <= 29:
        for i in range(y_range[0], y_range[1]):
            colorCount = colorCheck(square_color[x_search[2]][y_search[i]],
                                     colorCount)
    #current row
    for i in range(y_range[0], y_range[1]):
        if i != 1:
            colorCount = colorCheck(square_color[x_search[1]][y_search[i]],
                                     colorCount)
    
    try:
        if currentColor == 1:
            happy = (colorCount['red']/(colorCount['blue']+colorCount['red'])
                     )*100
        else:
            happy = (colorCount['blue']/(colorCount['blue']+colorCount['red'])
                     )*100
    except:
        #division by zero, skip the square
        return False
    
    if happy >= similarity:
        return False
    else:
        return True
#---------------------------------------------------------------
# Syntax: runProgram()
# Parameter: None
# Return Value: None
# Description: Runs oneStep() constantly until it either finishes, or runs into
#              an error with a bad similarity value.
def runProgram():
    run = False
    while run == False:
        run = oneStep()
        if run == 1:
            run = True
        #errorBox()
        
#---------------------------------------------------------------
# Syntax: updateSimilarity()
# Parameter: None
# Return Value: None
# Description: Used to grab the similarity text box's information and update
#              the Similarity to its value.  Along with error checking.
def updateSimilarity():	
    global similarity
    global text_box
    
    sim_num = text_box[0].getText()
    if floatCheck(sim_num):
        if 0 <= float(sim_num) <= 100:
            similarity = float(sim_num)
            errorBox('')
        else:
            similarity = "rangeErr"
            errorBox("Please enter a number between 0 and 100.")
    else:
        similarity = None        
        errorBox("Invalid Similarity Percentage")

# Syntax: floatCheck(string)
# Parameter: string - The string to check if it is a float value.
# Return Value: True if the string can be turned into a floating point number.
#               False otherwise.
# Description: Checks if
def floatCheck(string):
    try:
        float(string)
        return True
    except:
        return False
#---------------------------------------------------------------
# Syntax: errorBox(string)
# Parameter: string - The error message
# Return Value: None
# Description: updates the errorBox with the error message.
def errorBox(string):
    global text_box    
    text_box[1].setText(string)

#---------------------------------------------------------------
# Syntax: main()
# Parameter: None
# Return Value: None
# Description: The main program, used to call all the functions to draw the
#              graph and computer the mouse clicks on the buttons.
def main():
    global win
    global step_counter
    
    win = GraphWin("Population Simulation", 1000, 650)    
    
    draw_squares()
    randomizer()
    for y in range(4):
        drawButton(700, y*100+50, y)    
    drawTextBox(775,550)
    drawSteps(930,20,step_counter)
    
    exit = False
    while exit == False:
        pt = win.getMouse()
        #button 1:  Random
        if (button_list[0].getP1().x <= pt.x and 
            button_list[0].getP2().x >= pt.x and
            button_list[0].getP1().y <= pt.y and 
            button_list[0].getP2().y >= pt.y):        
            randomizer()
            updateSteps(step_counter)
        #button 2: Step
        if (button_list[1].getP1().x <= pt.x and 
            button_list[1].getP2().x >= pt.x and
            button_list[1].getP1().y <= pt.y and 
            button_list[1].getP2().y >= pt.y):
            oneStep()
        #button 2: Run
        if (button_list[2].getP1().x <= pt.x and 
            button_list[2].getP2().x >= pt.x and
            button_list[2].getP1().y <= pt.y and 
            button_list[2].getP2().y >= pt.y):
            runProgram()        
        #button 4: Exit
        if (button_list[3].getP1().x <= pt.x and 
            button_list[3].getP2().x >= pt.x and
            button_list[3].getP1().y <= pt.y and 
            button_list[3].getP2().y >= pt.y):
            exit = True
    win.close()

main()