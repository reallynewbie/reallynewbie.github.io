README:

AnagramsH.c - The Anagrams program
dictH.c - the Dictionary program with getopt support
hashP.c - hashing program that interfaces with the structs in hashP.h
hashP.h - Header file for hashP.c, contains structs for DictH/Anagrams

README - quick writeup of this stuff.