#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "hashP.h"

/*--------------------------------------------------------------------------*\
 *  NAME:  Dictionary create(int initial_capacity, int delta_capacity);
 *  DESCRIPTION:
 *      Create a new Dictionary and return a handle to the Dictionary.
 *  ARGUMENTS:
 *      int initial_capacity - the beginning max capacity
 *      int delta_capacity - when expanding the dictionary, it grows by delta_capacity
 *  RETURNS:
 *      someTable - which is a dictionary.
 *  NOTE:
 *      I used the lecture's studentinfo sample C code as a guideline for this function.
\*--------------------------------------------------------------------------*/
Dictionary create(int initial_capacity, int delta_capacity)
{
    int i = 0;

    Dictionary someTable = malloc(sizeof(hashTable *));
    if (someTable == NULL)
    {
        fprintf(stderr, "ERROR: malloc failed\n");
        exit(EXIT_FAILURE);
    }
    someTable->data = malloc(initial_capacity * sizeof(entry *));

    if (someTable->data == NULL)
    {
        fprintf(stderr, "ERROR: malloc failed for entry array\n");
        exit(EXIT_FAILURE);
    }

    someTable->table_cursize = 0;
    someTable->table_delta_capacity = delta_capacity;
    someTable->table_maxsize = initial_capacity;
    someTable->table_maxindex = initial_capacity - 1;
    for (; i < initial_capacity; i++) // Set all array entries to NULL for the start
    {
        someTable->data[i] = NULL;
    }

    return someTable;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  void destroy(Dictionary table)
 *  DESCRIPTION:
 *      Goes through the dictionary and frees every single malloc'd entry
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *  RETURNS:
 *      None
\*--------------------------------------------------------------------------*/
void destroy(Dictionary table)
{
    int i = 0;
    for (; i < (table->table_maxindex); i++)
    {
        if (table->data[i] != NULL)
        {
            if (table->data[i]->word != NULL) //Free the insides then move outside.
                free(table->data[i]->word);
            if (table->data[i]->defn != NULL)
                free(table->data[i]->defn);
        }
        free(table->data[i]);
    }
    free(table->data);
    free(table);
}

/*--------------------------------------------------------------------------*\
 *  NAME:  int exists(Dictionary table, char *index)
 *  DESCRIPTION:
 *      Checks if the word "index" exists in the dictionary.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through.
 *      char *word - the word we will be searching for.
 *  RETURNS:
 *      Returns 1 if it exists in the table, and 0 if it does not exist.
\*--------------------------------------------------------------------------*/
int exists(Dictionary table, char *index)
{
    int tableIndex = getHash(index) % table->table_maxsize;
    /*The following whileloop checks the following:
    * (tableIndex <= (table->table_maxindex) - Ensures that tableIndex doesn't go above the max indexOccupied
    * (table->data[tableIndex] != NULL) - When looping through the dictionary, if NULL is found, that means that linear probing collisions have ended there.
    * (strlen(table->data[tableIndex]->word) != 0)) - When I delete entries, I replace them with a blankEntry of type Entry which has Word = "", and Defn = "".  Which both have a strlen of 0.data
    */
    while ((tableIndex <= (table->table_maxindex) && (table->data[tableIndex] != NULL) && (strlen(table->data[tableIndex]->word) != 0)))
    {
        if (strcmp(table->data[tableIndex]->word, index) == 0)
        {
            return 1;
        }
        tableIndex++;
    }
    // The following section covers the case where linear probing collisions brought the collisions to the beginning of the dictionary indexes.
    if (tableIndex == table->table_maxsize)
    {
        tableIndex = 0;
        while ((tableIndex <= (table->table_maxindex) && (table->data[tableIndex] != NULL) && (strlen(table->data[tableIndex]->word) != 0)))
        {
            if (strcmp(table->data[tableIndex]->word, index) == 0)
            {
                return 1;
            }
            tableIndex++;
        }
    }

    return 0;
}
/*--------------------------------------------------------------------------*\
 *  NAME:  updateDef(Dictionary table, char *word, char *defn)
 *  DESCRIPTION:
 *      Used in anagramsH.c to update just the definition when provided the word
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      char *word - the word we will be updating.
 *      char *defn - the definition we'll be updating.
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void updateDef(Dictionary table, char *index, char *value)
{
    int tableIndex = getHash(index) % table->table_maxsize;
    if (strcmp(table->data[tableIndex]->word, index) == 0)
    {
        strcpy(table->data[tableIndex]->defn, value);
        return;
    }
    else
    {
        while (strcmp(table->data[tableIndex]->word, index) != 0)
        {
            tableIndex++;
            if (tableIndex == table->table_maxsize)
                tableIndex = 0;
            if (strcmp(table->data[tableIndex]->word, index) == 0)
            {
                strcpy(table->data[tableIndex]->defn, value);
                return;
            }
        }
    }
}
/*--------------------------------------------------------------------------*\
 *  NAME:  indexOccupied(Dictionary table, int index)
 *  DESCRIPTION:
 *      Looks at table->data[index] to see if it equals null, or not.
 *      I used this mainly to quickly assert if the index is used in order to 
 *      deal with collisions via linear probing.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      Int index - the index we're checking if it is occupied.
 *  RETURNS:
 *      0 - if empty.  1 - if not empty.
\*--------------------------------------------------------------------------*/
int indexOccupied(Dictionary table, int index)
{
    if (table->data[index] == NULL)
    {
        return 0;
    }
    return 1;
}
/*--------------------------------------------------------------------------*\
 *  NAME:  unsigned long getHash(char * word)
 *  DESCRIPTION:
 *      Uses a modified version of DJB2 that I took from http://www.cse.yorku.ca/~oz/hash.html
 *      The version on the website did not work, so I took the liberty of converting
 *      it into a more C-compatible version.  The old version never went into the whileloop at all.
 *          unsigned long
 *   hash(unsigned char *str)
 *   {
 *       unsigned long hash = 5381;
 *       int c;
 *
 *       while (c = *str++)
 *           hash = ((hash << 5) + hash) + c;
 *
 *      return hash;
 *   }
 *  ARGUMENTS:
 *      char *word - the word we will be hashing.
 *  RETURNS:
 *      A unsigned long number which represents the hash.
\*--------------------------------------------------------------------------*/
unsigned long getHash(char *word)
{
    unsigned long index = 5381;
    int c = 0;

    while (*word) // c=*str++ doesn't work in C.  So i changed it to suit C.
    {
        c = *word;
        index = ((index << 5) + index) + c; /* index * 33 + c */
        word++;
    }
    return index;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  void insertEntry(Dictionary table, char *index, char *value)
 *  DESCRIPTION:
 *      Inserts an entry into the table.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we are inserting this into
 *      char *word - the word we will be inserting
 *      char *defn - the definition we'll be inserting
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void insertEntry(Dictionary table, char *index, char *value)
{
    if (table->table_cursize >= table->table_maxsize * 3 / 4) // Grows the table when it is 3/4 full.
    {
        grow(table, table->table_maxsize + table->table_delta_capacity);
    }
    int tableIndex = getHash(index) % table->table_maxsize;
    int existing = indexOccupied(table, tableIndex);

    if (existing == 0) // The index is empty here.
    {
        table->data[tableIndex] = malloc(sizeof(entry *));

        table->data[tableIndex]->word = malloc(strlen(index) + 1);
        table->data[tableIndex]->defn = malloc(strlen(value) + 1);

        strcpy(table->data[tableIndex]->word, index);
        strcpy(table->data[tableIndex]->defn, value);
    }
    else // Index contains something, we need to do collision resolution.
    {
        printf("\nIndex:  %d  Collision happened\n", table->table_maxsize);
        while (existing != 0)
        {
            tableIndex++;
            if (tableIndex > table->table_maxindex)
            {
                tableIndex = 0;
            }

            existing = indexOccupied(table, tableIndex);
        }
        table->data[tableIndex] = malloc(sizeof(entry *));

        table->data[tableIndex]->word = malloc(strlen(index) + 1);
        table->data[tableIndex]->defn = malloc(strlen(value) + 1);

        strcpy(table->data[tableIndex]->word, index);
        strcpy(table->data[tableIndex]->defn, value);
    }
    table->table_cursize++; // make sure to increase cursize when inserting.
}

char *getEntry(Dictionary table, char *index)
{
    int tableIndex = getHash(index) % table->table_maxsize;
    while ((table->data[tableIndex] != NULL) && (tableIndex <= table->table_maxindex + 1))
    {
        if (strcmp(table->data[tableIndex]->word, index) == 0)
            return (table->data[tableIndex]->defn);
        tableIndex++;
        if (tableIndex == table->table_maxindex + 1)
        {
            tableIndex = 0;
        }
    }
    return NULL;
}

void deleteEntry(Dictionary table, char *index)
{
    int tableIndex = getHash(index) % table->table_maxsize;

    //Create a blankentry so I can put it in each deleted spot.  That way I can still
    //use exists to search the dictionary for a term.
    entry *blankEntry = malloc(sizeof(entry));
    blankEntry->word = malloc(1);
    strcpy(blankEntry->word, "");
    blankEntry->defn = malloc(1);
    strcpy(blankEntry->defn, "");

    while ((table->data[tableIndex] != NULL) && tableIndex <= table->table_maxindex + 1)
    {
        if (tableIndex == table->table_maxindex + 1)
        {
            tableIndex = 0;
        }
        if (strcmp(table->data[tableIndex]->word, index) == 0)
        {
            strcpy(table->data[tableIndex]->word, "");
            strcpy(table->data[tableIndex]->defn, "");

            table->table_cursize--;
            return;
        }
        tableIndex++;
    }

    return;
}
}

/*--------------------------------------------------------------------------*\
 *  NAME:  void printAll(Dictionary table);
 *  DESCRIPTION:
 *      Loops through the dictionary and prints all available indexes with their
 *      "word".
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void printAll(Dictionary table)
{
    int i;
    for (i = 0; i < table->table_maxsize; i++)
    {
        if (table->data[i] != NULL)
        {
            if (strcmp(table->data[i]->word, "") != 0)
                printf("Index: %d -- Word:  %s\n", i, table->data[i]->word);
            else
                printf("Index: %d -- Word:  Deleted Entry\n", i);
        }
        else
        {
            printf("Index: %d -- Word:  Null\n", i);
        }
    }
    return;
}
void applyFunction(Dictionary table, hash_traverse_fn *f)
{
    int i = 0;
    for (; i < table->table_maxsize; i++)
    {
        if (table->data[i] != NULL)
            f(*(table->data[i]));
    }
}
/*--------------------------------------------------------------------------*\
 *  NAME:  void grow(Dictionary table, int newSize);
 *  DESCRIPTION:
 *      Creates a new, larger data **entry structure and populates it with all
 *      of the old table's entries that are not NULL/deleted.  After this,  it
 *      replaces the table->data with the new array.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      int newSize - the new size of the table.
 *  RETURNS:
 *      None, however as a side effect, it changes table->data's pointer to the
 *      new malloc'd table created within grow.
\*--------------------------------------------------------------------------*/
void grow(Dictionary table, int newSize)
{
    int i, tableIndex = 0;
    entry **newTable = malloc(newSize * sizeof(entry *));

    for (i = 0; i < newSize; i++)
    {
        newTable[i] = NULL;
    }

    for (i = 0; i < table->table_maxsize; i++)
    {
        if (table->data[i] != NULL && strlen(table->data[i]->word) != 0)
        {
            tableIndex = getHash(table->data[i]->word) % newSize;
            if (newTable[tableIndex] != NULL)
            {
                while (newTable[tableIndex] != NULL)
                {
                    tableIndex++;
                    if (tableIndex == newSize)
                    {
                        tableIndex = 0;
                    }
                }
            }
            newTable[tableIndex] = table->data[i];
        }
    }
    table->table_maxsize = newSize;
    table->table_maxindex = newSize - 1;
    table->data = newTable;
}


int test()
{
    Dictionary donkey1 = create(5, 3);
    printf("Printing empty dictionary of size 5.");
    printAll(donkey1);

    char *someWord = "Test";
    char *theDef = "This is a small test.";
    
    insertEntry(donkey1, someWord, theDef);
    insertEntry(donkey1, "finger", "FingerTest");
    insertEntry(donkey1, "word1", "word1def");
    insertEntry(donkey1, "someWord", "word2def");

    printAll(donkey1);
    
    printf("Adding more words\n");
    insertEntry(donkey1, "word3", "word2def");
    insertEntry(donkey1, "abc abc", "word2def");
    insertEntry(donkey1, "abc", "jojojo");
    insertEntry(donkey1, "ppout", "word2def");
    insertEntry(donkey1, "trout", "word2def");
    insertEntry(donkey1, "word7", "word2def");
    printAll(donkey1);

    printf("Should be ="This is a small test".\nBegin getEntry:\n%s\n", getEntry(donkey1, someWord));
    printf("Begin Exists: %d\n", exists(donkey1, someWord));

    printf("Deleting the word 'test'\n");
    deleteEntry(donkey1, someWord);
    printAll(donkey1);

    destroy(donkey1);
    return 0;
}
