﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using FindUsernameandFiles; //found in FileOperation.cs
using System.Windows.Forms;
using System.Drawing;
using System.IO;
using Microsoft.Office.Interop.Outlook;
using System.Windows;
using Microsoft.Win32;


namespace OutlookAddIn1
{
    public partial class Ribbon1
    {
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            refreshTemplateList();
        }

        private void but_Load_Click(object sender, RibbonControlEventArgs e)
        {
            string defaultFolder = ThisAddIn.defaultPath;
            string selectedFile = ddTemplates.SelectedItem + ".oft";
            System.Diagnostics.Process.Start(@defaultFolder+selectedFile);
        }

        private void but_Save_Click(object sender, RibbonControlEventArgs e)
        {
            saveDialog userInputBox = new saveDialog();

            if (userInputBox.ShowDialog() == DialogResult.OK)
            {
                string dialogFileName = userInputBox.saveDialogText.Text;
                string saveLocation = ThisAddIn.defaultPath + dialogFileName + ".oft";
                MessageBox.Show("Saved Template: "+saveLocation);
                Globals.ThisAddIn.Application.ActiveExplorer().Selection[1].SaveAs(saveLocation, Microsoft.Office.Interop.Outlook.OlSaveAsType.olTemplate);
                refreshTemplateList();
            }
        }
        public void refreshTemplateList()
        {
            this.ddTemplates.Items.Clear();
            var rFilename = new List<ThisAddIn.Template>();
            rFilename = ThisAddIn.readFileName();
            ILookup<string, ThisAddIn.Template> displayedFilename = rFilename.ToLookup(rFileName => rFileName.tFileName);
            for (int i = 0; i < displayedFilename.Count; i++)
            {
                RibbonDropDownItem item = Globals.Factory.GetRibbonFactory().CreateRibbonDropDownItem();
                item.Label = rFilename[i].tFileName;
                this.ddTemplates.Items.Add(item);
            }
        }
    }
}
