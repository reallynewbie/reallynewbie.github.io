﻿namespace OutlookAddIn1
{
    partial class saveDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.saveDialogText = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.saveDialogCancel = new System.Windows.Forms.Button();
            this.saveDialogOK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // saveDialogText
            // 
            this.saveDialogText.Location = new System.Drawing.Point(15, 32);
            this.saveDialogText.Name = "saveDialogText";
            this.saveDialogText.Size = new System.Drawing.Size(384, 20);
            this.saveDialogText.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Please name the template.";
            // 
            // saveDialogCancel
            // 
            this.saveDialogCancel.Location = new System.Drawing.Point(324, 60);
            this.saveDialogCancel.Name = "saveDialogCancel";
            this.saveDialogCancel.Size = new System.Drawing.Size(75, 23);
            this.saveDialogCancel.TabIndex = 2;
            this.saveDialogCancel.Text = "Cancel";
            this.saveDialogCancel.UseVisualStyleBackColor = true;
            this.saveDialogCancel.Click += new System.EventHandler(this.saveDialogCancel_Click);
            // 
            // saveDialogOK
            // 
            this.saveDialogOK.Location = new System.Drawing.Point(235, 60);
            this.saveDialogOK.Name = "saveDialogOK";
            this.saveDialogOK.Size = new System.Drawing.Size(75, 23);
            this.saveDialogOK.TabIndex = 3;
            this.saveDialogOK.Text = "OK";
            this.saveDialogOK.UseVisualStyleBackColor = true;
            this.saveDialogOK.Click += new System.EventHandler(this.saveDialogOK_Click);
            // 
            // saveDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(409, 92);
            this.Controls.Add(this.saveDialogOK);
            this.Controls.Add(this.saveDialogCancel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.saveDialogText);
            this.Name = "saveDialog";
            this.Text = "Save Template";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button saveDialogCancel;
        private System.Windows.Forms.Button saveDialogOK;
        public System.Windows.Forms.TextBox saveDialogText;
    }
}