
/*
 *  Interface specification for your hash table implementation
 *
 *  Constructors/Destructors: create, destroy
 *  Properties: exists
 *  Methods: insertEntry, getEntry, deleteEntry, applyFunction
 *
 *  DO NOT MODIFY ANYTHING THAT IS PART OF THE INTERFACE SPECIFICATION (UNLESS EXPLICITLY
 *  INDICATED).  TO DO SO WILL PREVENT YOUR CODE FROM LINKING WITH OUR CODE!!
 */

#ifndef hashP_H
#define hashP_H

typedef struct {
  char * word;
  char * defn;
} entry;

/* Replace the following with your implementation declarations, but your structure must be typedef'd to hashTable */
typedef struct {
  int table_maxsize;
  int table_cursize;
  int table_delta_capacity;
  int table_maxindex;  //Added maxindex which is representing the maxsize-1, this is to improve readability.
  entry **data;
} hashTable;
/* end of your implementation declarations */

typedef hashTable* Dictionary;


Dictionary create(int initial_capacity, int delta_capacity);
/*
 * Create a new Dictionary and return a handle to the Dictionary.
 *
 * Pre: initial_capacity >= 0, delta_capacity >= 0;
 *
 * Post: returns a handle to an empty Dictionary that has an initial capacity of
 * 	 initial_capacity items, and that is expanded by delta_capacity
 * 	 items when the Dictionary fills up (if you are using a hash table method where table full is relevant,
 * otherwise delta_capacity is ignored.  Do not change the prototype though!
 * We need it to match for our test program).
 * 	 returns NULL on failure
 *
 * Side Effects: allocates storage.
 */

void destroy (Dictionary table);
/*
 * Destroy an existing Dictionary with handle table.
 *
 * Pre: table is a valid handle
 * Post: none
 *
 * Side Effects: all memory allcated for the map is freed, including memory
 * associated with the actual data in an item.
 */

int exists(Dictionary table, char * index);
/*
 * Test if word index exists in the table with matching definition
 *
 * Pre: table is a valid handle
 * Post: returns 1 if index exists in the table, that is if a table contains
 *       a pair <index,def> for some value def, 0 otherwise
 *
 */


/*--------------------------------------------------------------------------*\
 *  NAME:  indexOccupied(Dictionary table, int index)
 *  DESCRIPTION:
 *      Looks at table->data[index] to see if it equals null, or not.
 *      I used this mainly to quickly assert if the index is used in order to 
 *      deal with collisions via linear probing.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      Int index - the index we're checking if it is occupied.
 *  RETURNS:
 *      0 - if empty.  1 - if not empty.
\*--------------------------------------------------------------------------*/
int indexOccupied(Dictionary table, int index);

/*--------------------------------------------------------------------------*\
 *  NAME:  updateDef(Dictionary table, char *word, char *defn)
 *  DESCRIPTION:
 *      Used in anagramsH.c to update just the definition when provided the word
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      char *word - the word we will be updating.
 *      char *defn - the definition we'll be updating.
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void updateDef(Dictionary table, char *word, char *defn);

/*--------------------------------------------------------------------------*\
 *  NAME:  unsigned long getHash(char * word)
 *  DESCRIPTION:
 *      Uses a modified version of DJB2 that I took from http://www.cse.yorku.ca/~oz/hash.html
 *      The version on the website did not work, so I took the liberty of converting
 *      it into a more C-compatible version.  The old version never went into the whileloop at all.
 *          unsigned long
 *   hash(unsigned char *str)
 *   {
 *       unsigned long hash = 5381;
 *       int c;
 *
 *       while (c = *str++)
 *           hash = ((hash << 5) + hash) + c;
 *
 *      return hash;
 *   }
 *  ARGUMENTS:
 *      char *word - the word we will be hashing.
 *  RETURNS:
 *      A unsigned long number which represents the hash.
\*--------------------------------------------------------------------------*/

unsigned long getHash(char * word);

void insertEntry(Dictionary table, char * index, char * value);
/*
 * Add an new entry to the table.
 *
 * Pre: table is a valid handle,
 *      index and value not NULL
 *
 * Post: a new entry is added to the hash table
 *
 * Side Effects: If the table already contains data with the given index, the
 * original associated value is discarded and replaced with the new value.
 * If the table does not contain the pair, the pair is added, with the
 * hash table being extended if it is full.
 *
 */


char * getEntry(Dictionary table, char * index);
/*
 * Fetch a value corresponding to an index, i.e. retrieve the definition that does with index
 *
 * Pre: table is a valid handle
 * Post: if index is in the table then return the definition that belongs with an index (word/term)
 *       if not, then return NULL.
 */


void deleteEntry(Dictionary table, char * index);
/*
 * Remove an entry from the hash table
 *
 * Pre: table is a valid handle
 * Post: the word-definition pair no longer exists in the table.
 * Side Effects: reclaims any storage associated with the data
 */


/*--------------------------------------------------------------------------*\
 *  NAME:  void printAll(Dictionary table);
 *  DESCRIPTION:
 *      Loops through the dictionary and prints all available indexes with their
 *      "word".
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void printAll(Dictionary table);

/*--------------------------------------------------------------------------*\
 *  NAME:  void grow(Dictionary table, int newSize);
 *  DESCRIPTION:
 *      Creates a new, larger data **entry structure and populates it with all
 *      of the old table's entries that are not NULL/deleted.  After this,  it
 *      replaces the table->data with the new array.
 *  ARGUMENTS:
 *      Dictionary table - the dictionary that we're searching through
 *      int newSize - the new size of the table.
 *  RETURNS:
 *      None, however as a side effect, it changes table->data's pointer to the
 *      new malloc'd table created within grow.
\*--------------------------------------------------------------------------*/
void grow (Dictionary table, int newSize);


/* this typedef is just an avoidance of typing the whole function pointer info in the next function prototype*/
typedef void hash_traverse_fn(const entry tableEntry);

void applyFunction (Dictionary table, hash_traverse_fn* f);
/*
 * Walk over all entries in the table and apply a function to each pair
 *
 * Pre: table is a valid handle, f does not modify the table contents
 * Post: none
 */

#endif

