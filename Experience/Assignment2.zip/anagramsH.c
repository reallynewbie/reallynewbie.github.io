#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "hashP.h"

/*--------------------------------------------------------------------------*\
 *  NAME:  void swapChar(char * cha1, char* cha2)
 *  DESCRIPTION:
 *      Swaps the position of two character pointers.
 *  ARGUMENTS:
 *      char * cha1 - Char 1's character
 *      char * cha2 - Char 2's character
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void swapChar(char * cha1, char* cha2)
{
    char temp = *cha1;
    *cha1 = *cha2;
    *cha2 = temp;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  int main()
 *  DESCRIPTION:
 *      given a range of strings separated by spaces, if the other words are anagrams
 *      of the first occurance of a unique anagram, print them.  Otherwise, add the unique
 *      word to a dictionary/hashtable
 *  ARGUMENTS:
 *      None
 *  RETURNS:
 *      0 on success.
\*--------------------------------------------------------------------------*/
int main()
{
    char line[301], *token, cha = 'z', sortedWord[100], originalWord[100];
    int i = 0, j = 0, smallest = 0;
    Dictionary wordDict = create(11, 6);

    fgets(line, 300, stdin);
    token = strtok(line, " "); // Because they are all separated by spaces, using strtok to go through the line.

    while (token != NULL) 
    {
        strcpy(originalWord, token);
        for (j = 0; j< strlen(token); j++)
        {
            cha = token[j];
            smallest = j;
            for (i = j; i < strlen(token); i++)
            {
                if (token[i] - '0' < cha - '0')
                {
                    smallest = i;
                    cha = token[i];
                }
            }
            //At this point I've found the "smallest" char in the string.
            swapChar((token+smallest), token+j); // Swap it with the current index of [j]
        }
        
        strcpy(sortedWord, token);

        if (exists(wordDict, sortedWord)== 0) //Checks if the signature of the anagram already exists in the dictionary.
        {
            insertEntry(wordDict, sortedWord, originalWord);
        }
        else
        {
            printf("%s %s\n", getEntry(wordDict, sortedWord), originalWord);
        }
        memset(originalWord, 0, strlen(originalWord)); // reset for next token
        memset(sortedWord, 0, strlen(sortedWord));
        token = strtok(NULL, " "); //Grab next token.
    }
    return 0;
}
