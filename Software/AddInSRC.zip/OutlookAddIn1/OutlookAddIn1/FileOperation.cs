﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Drawing;


namespace FindUsernameandFiles
{
    class FileOperation
    {
        static void Main(string[] args)
        {
            string Path = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

            var finalPath = new List<string>();
            var finalFileName = new List<string>();
            string[] fileEntries = Directory.GetFiles(Path);
            foreach (string fileName in fileEntries)
            {
                if (fileName.EndsWith(".oft"))
                {
                    finalPath.Add(fileName);
                    finalFileName.Add(FileFormat1(fileName));
                }
            }
        }
        public static string FileFormat1(string FileArray)
        {
            if (FileArray.EndsWith(".oft"))
            {
                string edit1 = FileArray.Substring(FileArray.IndexOf(@"Documents") + 10);
                int fileExtPos = edit1.LastIndexOf(".");
                if (fileExtPos >= 0)
                {
                    edit1 = edit1.Substring(0, fileExtPos);
                }
                return edit1;
            }
            else
            {
                return null;
            }
        }
    }
}
