﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Windows.Forms;
using System.Text;
using System.Xml.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;

namespace OutlookAddIn1
{
    public partial class ThisAddIn
    {
        public static string defaultPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "\\Outlook Templates\\";

        public void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            folderCheck();//Checks if the Default Folder is there
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }
        public void folderCheck()
        {
            bool folderExist = System.IO.Directory.Exists(defaultPath);
            if (!folderExist)
            {
                System.IO.Directory.CreateDirectory((defaultPath));
            }
        }
        public class Template
        {
            public string tFileName { get; set;}
            public string tPath { get; set;}

        }
        public static List<Template> readFileName()
        {
            string[] fileEntries = Directory.GetFiles(defaultPath);
            var compiledFiles = new List<Template>();
            foreach (String fileName in fileEntries)
            {
                if (fileName.EndsWith(".oft"))
                {
                    compiledFiles.Add(new Template 
                    {
                        tPath = fileName,
                        tFileName = removePathExtension(fileName)
                    });
                }
            }
            return compiledFiles;

        }
        public static string removePathExtension(string theFile)//removes both the beginning and end of the filename for the dropdown list
        {
            if (theFile.EndsWith(".oft"))
            {
                string edit1 = Path.GetFileNameWithoutExtension(theFile);
                return edit1;
            }
            else
            {
                return null;
            }
        }
        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion
    }
}
