#define _GNU_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <getopt.h>
#include "hashP.h"

/*--------------------------------------------------------------------------*\
 *  NAME:  char *findWord(char *line)
 *  DESCRIPTION:
 *      Separates out the "word" in the first line of input.
 *  ARGUMENTS:
 *      char *line - the first line of input from a file.  In the format of 
 *      "ABC. Definition".
 *  RETURNS:
 *      A copy of a string containing the word.
\*--------------------------------------------------------------------------*/
char *findWord(char *line)
{
    int position = 0;
    if (strchr(line, '.') != NULL)
    {
        position = strchr(line, '.') - line; //find the period to find the word.
    }
    else
    {
        return NULL;
    }

    char *a = malloc(position);
    char *cpy = malloc(position);
    for (int i = 0; i < position; i++)
    {
        if (line[i] == toupper(line[i]))
        {
            a[i] = line[i];
        }
        else
            return NULL;
    }
    a[position] = '\0';
    strcpy(cpy, a);
    return cpy;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  char *findDef(char *line)
 *  DESCRIPTION:
 *      Separates out the "definition" in the first line of input.
 *  ARGUMENTS:
 *      char *line - the first line of input from a file.  In the format of 
 *      "ABC. Definition".
 *  RETURNS:
 *      A copy of a string containing the definition.
\*--------------------------------------------------------------------------*/
char *findDef(char *line)
{
    char *position = strchr(line, '.') + 2;
    char *a = malloc(strlen(line) + 1);

    strcpy(a, position);
    return a;
}


/*--------------------------------------------------------------------------*\
 *  NAME:  char *addLine(char *line)
 *  DESCRIPTION:
 *      Separates the additional lines of definition from the pointer and RETURNS
 *      a copy of the string.
 *  ARGUMENTS:
 *      char *line - An additional line of the definition from a file.  In the format of 
 *      "Definition\n".
 *  RETURNS:
 *      A copy of a string containing the definition.
\*--------------------------------------------------------------------------*/
char *addLine(char *line)
{
    int position = strchr(line, '\n') - line;
    char *a = malloc(position);
    char *cpy = malloc(position);
    for (int i = 0; i < position; i++)
    {
        a[i] = line[i];
    }
    a[position] = ' ';
    strcpy(cpy, a);
    return cpy;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  void writeToDict(Dictionary table, char * outFilename)
 *  DESCRIPTION:
 *      Writes all dictionary values to a file.  Provided they aren't null/deleted
 *  ARGUMENTS:
  *      Dictionary table - the dictionary that we're taking all entries from
 *      char * outFilename - the filename of the written to file.
 *  RETURNS:
 *      None.
\*--------------------------------------------------------------------------*/
void writeToDict(Dictionary table, char * outFilename)
{
    FILE *out_file;
    out_file=fopen(outFilename, "w");
    if (out_file == NULL)
    {
        fprintf(stderr, "Can't open file %s for writing.\n", outFilename);
        exit(EXIT_FAILURE); //can't open file
    }

    int i;
    for (i = 0; i < table->table_maxsize; i++)
    {
        if (table->data[i] != NULL)
        {
            fprintf(out_file, "%s. ", table->data[i]->word);
            fprintf(out_file, "%s", table->data[i]->defn);
            fprintf(out_file, "\n");
        }
    }
    return;
}

/*--------------------------------------------------------------------------*\
 *  NAME:  int main(int argc, char **argv)
 *  DESCRIPTION:
 *      Reads all entries from a dictionary file, then depending on the mode of 
 *      -a, -l, -m, proceeds to do things to them.
 *      -a:  adds the first filename's dictionary entries to the -d's dictionary
             entries
        -l:  Spellchecks the entries in in_filename to the dictionary entries in 
             out_filename.  Prints the entries that are spelled wrong.
        -m:  prints the matched words, and their definitions.  Does not print missing
             entries.
 *  ARGUMENTS:
 *      argc/argv - used for getopt to select the modes
 *  RETURNS:
 *      0 if successful in running.  returns Errors if there are any.
 *  NOTE:
 *      Used getopt code from class
\*--------------------------------------------------------------------------*/
int main(int argc, char **argv)
{
    int c, mode = 0, readResult;
    char *inFilename, *outFilename, *line = NULL;
    FILE *in_file, *out_file;
    size_t size = 0;

    while ((c = getopt(argc, argv, ":a:l:m:d:")) != -1)
    {
        switch (c)
        {
        case 'a':
            inFilename = optarg;
            mode = 'a';
            break;
        case 'd':
            outFilename = optarg;
            break;
        case 'l':
            mode = 'l';
	    inFilename = optarg;
            break;
        case 'm':
            mode = 'm';
	    inFilename = optarg;
            break;
        case ':': // case for missing
            printf("missing some arguments\n");
            break;
        case '?': // case for invalid option
            printf("Invalid option of %c", c);
            break;
        }
    }
    in_file = fopen(inFilename, "r");
    out_file = fopen(outFilename, "r");

    if (in_file == NULL)
    {
        fprintf(stderr, "Can't open file %s\n", inFilename);
        exit(EXIT_FAILURE); //can't open file
    }
    if (out_file == NULL)
    {
        fprintf(stderr, "Can't open file %s\n", outFilename);
        exit(EXIT_FAILURE); //can't open file
    }
    //------------------------------------
    //Begin populating master dictionary with out_file's entries
    Dictionary masterDict = create(101, 77); 
    char *word, definition[500];
    int firstLine = 1;
    memset(definition, 0, strlen(definition)); // reset definition for use in copying definitions.

    while ((readResult = getline(&line, &size, out_file)) != -1)
    {
        if (ferror(out_file))
        {
            fprintf(stderr, "getline failure.");
            fclose(in_file);
            fclose(out_file);
            exit(EXIT_FAILURE);
        }
        //If the first line is being read, I need to separate out the word/definition.
        if (firstLine == 1)
        {
            word = findWord(line);
            strcpy(definition, findDef(line));
            firstLine = 0;
        }
        else //If it isn't the 1st line, then I can look for more definitions, or insert the entry
        {
            if (strcmp(line, "\n") == 0) //If it is a empty line, that means it's the end of the entry.
            {
                //  Troubleshooting: printf("\n-----------\nWord = %s, Def = %s\n------------\n", word, definition);
                insertEntry(masterDict, word, definition);
                //  Troubleshooting:  printf("%s", getEntry(masterDict, word));
                memset(definition, 0, strlen(definition));
                firstLine = 1;
            }
            else
            {
                strcat(definition, line);
            }
        }
    }
    // for troubleshooting.printAll(masterDict);
    // Finished reading in all entries.
    int existing = 0;
    firstLine = 1;
    memset(definition, 0, strlen(definition));
    //Begin evaluating the mode that was selected by the user.
    switch (mode)
    {
    case 'a': // Add entries from in_file to the out_file.
        while ((readResult = getline(&line, &size, in_file)) != -1)
        {
            if (ferror(in_file))
            {
                fprintf(stderr, "getline failure.");
                fclose(in_file);
                fclose(out_file);
                exit(EXIT_FAILURE);
            }
            if (firstLine == 1)
            {
                word = findWord(line);
                strcpy(definition, findDef(line));
                firstLine = 0;
            }
            else
            {
                if (strcmp(line, "\n") == 0)
                {
                    existing = exists(masterDict, word); // Checks if the entries already exist in the dictionary.
                    if (existing == 0)
                    {
                        insertEntry(masterDict, word, definition);
                    }
                    else
                    {
                        updateDef(masterDict, word, definition); // Update definition if it already exists.
                    }
                    memset(definition, 0, strlen(definition));
                    firstLine = 1;
                }
                else
                {
                    strcat(definition, line);
                }
            }
        }
        //At this point, all in_file entries have been added to the dictionary.
        writeToDict(masterDict, outFilename);
        break;

    case 'l': // SpellCheck
       
        while ((readResult = getline(&line, &size, in_file)) != -1)
        {
            if (ferror(in_file))
            {
                fprintf(stderr, "getline failure.");
                fclose(in_file);
                fclose(out_file);
                exit(EXIT_FAILURE);
            }
            if (strcmp(line, "\n") != 0)
            {
                word = findWord(line);
                if (exists(masterDict, word) == 0)
                {
                    printf("%s\n", word);
                }
            }
        }
        break;

    case 'm': // look for definitions
        while ((readResult = getline(&line, &size, in_file)) != -1)
        {
            if (ferror(in_file))
            {
                fprintf(stderr, "getline failure.");
                fclose(in_file);
                fclose(out_file);
                exit(EXIT_FAILURE);
            }
            if (strcmp(line, "\n") != 0)
            {
                word = findWord(line);
                if (exists(masterDict, word))
                {
                    printf("%s %s\n", word, getEntry(masterDict, word));
                }
            }
        }
        break;
    default:
        printf("No valid mode selected.");
        break;
    }
    fclose(in_file);
    fclose(out_file);
    return 0;
}
